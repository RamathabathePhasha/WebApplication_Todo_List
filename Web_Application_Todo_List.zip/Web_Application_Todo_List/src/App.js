import React from 'react';
import "./App.css";
import WebApplication from './components/WebApplication';
/*import ArithmetricApp from './components/ArithmetricApp';*/
/*import Todo from "./components/Todo";*/
/*import ChangeText from './components/ChangeText';*/
/*import Counter from "./components/Counter";*/


function App() {
  return (
    <div className="App">
     <WebApplication/>
    </div>
  );
}

export default App;
