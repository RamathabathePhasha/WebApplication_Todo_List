import React, { useRef, useState } from 'react';
import './WebApplication.css';

function WebApplication() {
  const taskInputRef = useRef(); // Renamed to taskInputRef for clarity
  const [todos, setTodos] = useState([]); // State to manage the list of tasks

  const addTask = () => {
    const task = taskInputRef.current.value;
    if (task.trim() !== '') {
      setTodos([...todos, { name: task, completed: false }]);
      taskInputRef.current.value = ''; // Clear the input field after adding the task
    }
  };

  const markAsCompleted = (index) => {
    const updatedTodos = [...todos];
    updatedTodos[index].completed = !updatedTodos[index].completed;
    setTodos(updatedTodos);
  };

  const deleteTask = (index) => {
    const updatedTodos = todos.filter((_, i) => i !== index);
    setTodos(updatedTodos);
  };

  return (
    <div>
      <h1>Web Application</h1>
      <label htmlFor="taskInput">Enter your task</label>
      <input type="text" id="taskInput" ref={taskInputRef} />
      <br />
      <button onClick={addTask}>Add task</button>
      <ul>
        {todos.map((todo, index) => (
          <li key={index} style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
            {todo.name}
            <button onClick={() => markAsCompleted(index)}>
              {todo.completed ? 'Mark as Incomplete' : 'Mark as Completed'}
            </button>
            <button onClick={() => deleteTask(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default WebApplication;
